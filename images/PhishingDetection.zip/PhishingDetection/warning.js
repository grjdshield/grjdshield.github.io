"use strict";

// ============================================
// GRJD Shield - Warning page
// Shows the blocked URL, phishing probability,
// and the warning signs found in the URL (from features.js).
// ============================================

document.addEventListener("DOMContentLoaded", () => {
    const $ = id => document.getElementById(id);

    const backButton = $("backButton");
    const detailsButton = $("detailsButton");
    const detailsLabel = $("detailsLabel");
    const detailsPanel = $("detailsPanel");
    const continueButton = $("continueButton");
    const continueHint = $("continueHint");
    const agreeCheckbox = $("agreeCheckbox");
    const actionStatus = $("actionStatus");

    const params = new URLSearchParams(location.search);
    const rawProbability = params.get("probability");

    let destinationUrl = null;   // the URL the user tried to open
    let busy = false;

    // ---------- 1. Detected URL ----------
    destinationUrl = validUrl(params.get("url"));
    $("detectedUrl").textContent =
        destinationUrl || "Missing or invalid website address.";

    // short link (bit.ly, t.co, ...): show where it really goes
    const realDestination = validUrl(params.get("dest"));
    if (realDestination) {
        $("realDestination").textContent = realDestination;
        $("destinationRow").hidden = false;
    }

    // the URL the Random Forest actually judged
    const judgedUrl = realDestination || destinationUrl;

    // ---------- 2. Phishing probability ----------
    const probability = Number(rawProbability);
    const hasProbability =
        rawProbability !== null && rawProbability.trim() !== "" &&
        Number.isFinite(probability) && probability >= 0 && probability <= 1;

    const percentText = hasProbability ? `${(probability * 100).toFixed(2)}%` : "Not available";
    $("phishingProbability").textContent = percentText;

    // animate the probability meter
    setTimeout(() => {
        $("probabilityBar").style.width = hasProbability ? `${probability * 100}%` : "0%";
    }, 60);

    // ---------- 4. Why it was flagged ----------
    renderReasons(judgedUrl);

    // ---------- 5. Buttons ----------
    detailsButton.addEventListener("click", () => {
        const open = detailsPanel.hidden;
        detailsPanel.hidden = !open;
        detailsButton.setAttribute("aria-expanded", String(open));
        detailsLabel.textContent = open ? "Hide Details" : "View Threat Details";
        if (open) detailsPanel.scrollIntoView({ behavior: "smooth", block: "start" });
    });

    agreeCheckbox.addEventListener("change", () => {
        actionStatus.textContent = "";
        updateContinueButton();
    });

    // Go back to a safe page
    backButton.addEventListener("click", async () => {
        if (busy) return;
        busy = true;
        backButton.disabled = true;
        updateContinueButton();
        actionStatus.textContent = "Returning to a safe page...";

        try {
            const tab = await chrome.tabs.getCurrent();
            if (!tab || tab.id === undefined) throw new Error("Current tab could not be identified.");

            try {
                await chrome.tabs.update(tab.id, { url: "chrome://newtab/" });   // Chrome / Edge
            } catch {
                // Firefox does not allow opening its new tab page this way
                if (history.length > 1) history.back();
                else await chrome.tabs.update(tab.id, { url: "about:blank" });
            }
        } catch (error) {
            console.error("Unable to return to safety:", error);
            busy = false;
            backButton.disabled = false;
            updateContinueButton();
            actionStatus.textContent = "Unable to open a safe page. Please close this tab.";
        }
    });

    // Continue once, only after the user agrees
    continueButton.addEventListener("click", async () => {
        if (busy) return;

        if (!agreeCheckbox.checked || !destinationUrl) {
            actionStatus.textContent = "Tick the box first.";
            return;
        }

        busy = true;
        backButton.disabled = true;
        updateContinueButton();
        actionStatus.textContent = "Opening the website...";

        try {
            // background.js allows this URL one time only.
            // The warning appears again the next time it is opened.
            const approval = await chrome.runtime.sendMessage({
                type: "ALLOW_URL_ONCE",
                url: destinationUrl
            });

            if (!approval || approval.success !== true) {
                throw new Error(approval?.error || "Could not register one-time approval.");
            }

            const tab = await chrome.tabs.getCurrent();
            if (!tab || tab.id === undefined) throw new Error("Current tab could not be identified.");

            await chrome.tabs.update(tab.id, { url: destinationUrl });

        } catch (error) {
            console.error("Unable to continue:", error);
            busy = false;
            backButton.disabled = false;
            updateContinueButton();
            actionStatus.textContent = error.message || "Unable to open the website. Please try again.";
        }
    });

    function updateContinueButton() {
        continueButton.disabled = !agreeCheckbox.checked || !destinationUrl || busy;

        if (!destinationUrl) continueHint.textContent = "Invalid URL";
        else if (busy) continueHint.textContent = "Please wait...";
        else if (!agreeCheckbox.checked) continueHint.textContent = "Tick the box first";
        else continueHint.textContent = "Opens this website one time only";
    }

    updateContinueButton();
});

// ============================================
// HELPERS
// ============================================

function validUrl(value) {
    if (!value) return null;
    try {
        const parsed = new URL(value);
        if (["http:", "https:"].includes(parsed.protocol) && parsed.hostname) return parsed.href;
    } catch { /* invalid */ }
    return null;
}

// Warning signs found in the URL (the same 30 features the model uses)
function findReasons(url) {
    const reasons = [];
    let f;
    let host = "";
    let tld = "";

    try {
        f = extractFeatures(url);
        host = new URL(url).hostname.toLowerCase();
        tld = host.includes(".") ? host.split(".").pop() : "";
    } catch {
        return reasons;
    }

    const add = (title, detail) => reasons.push({ title, detail });

    if (f.has_ip_address) {
        add("Uses an IP address", "Real websites use a name. This one uses numbers instead.");
    }
    if (f.at_symbol_flag) {
        add("Contains an @ symbol", "This trick can hide the real website address.");
    }
    if (f.punycode_flag) {
        add("Uses look-alike letters", "Special characters (punycode) can copy the name of a real website.");
    }
    if (!f.https_flag) {
        add("No secure connection", "The address uses HTTP instead of HTTPS.");
    }
    if (!f.has_ip_address && !f.tld_popularity && tld) {
        add("Uncommon domain ending", `".${tld}" is rarely used by trusted websites.`);
    }
    if (f.domain_hyphen_count >= 1) {
        add("Hyphens in the website name",
            `${f.domain_hyphen_count} hyphen(s). Fake sites often use names like "secure-login-bank".`);
    }
    if (f.subdomain_count >= 2) {
        add("Many subdomains", `${f.subdomain_count} subdomains can make a fake site look like a real one.`);
    }
    if (!f.has_ip_address && f.domain_digit_count >= 2) {
        add("Numbers in the website name", `${f.domain_digit_count} digits. Random numbers are common in fake sites.`);
    }
    if (!f.has_ip_address && f.domain_name_length >= 6 && f.domain_vowel_ratio < 0.18) {
        add("Random-looking website name", "The name looks like random letters, not a real brand.");
    }
    if (f.suspicious_file_extension) {
        add("Suspicious file type", "The link points to a file type often used in attacks.");
    }
    if (f.port_flag) {
        add("Unusual port number", "Normal websites do not need a port number in the address.");
    }
    if (f.url_length > 75) {
        add("Very long address", `${f.url_length} characters. Long links can hide the real website.`);
    }
    if (f.query_param_count >= 3) {
        add("Many hidden parameters", `${f.query_param_count} parameters are attached to this link.`);
    }

    return reasons.slice(0, 6);
}

function renderReasons(url) {
    const list = document.getElementById("reasonList");
    list.replaceChildren();

    let reasons = url ? findReasons(url) : [];

    if (!reasons.length) {
        reasons = [{
            title: "Matches phishing patterns",
            detail: "The overall combination of features in this address is similar to phishing websites the model learned from."
        }];
    }

    reasons.forEach(reason => {
        const item = document.createElement("li");
        const text = document.createElement("div");
        const title = document.createElement("strong");
        const detail = document.createElement("span");

        title.textContent = reason.title;
        detail.textContent = reason.detail;

        text.append(title, detail);
        item.appendChild(text);
        list.appendChild(item);
    });
}
