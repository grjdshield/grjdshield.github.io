
"use strict";

// Wrapped so this file can also run inside the Firefox background page
// (Firefox has no offscreen documents) without clashing with background.js
(() => {

// ==========================================
// PHISHING DETECTOR - OFFSCREEN MODEL
// Random Forest ONNX - 30 Features
// Final Augmented Model
// ==========================================

// ==========================================
// MODEL CONFIGURATION
// ==========================================

const MODEL_PATH = chrome.runtime.getURL(
    "model/random_forest_phishing_model_final.onnx"
);

const EXPECTED_FEATURES = 30;

// Class mapping:
// Class 0 = Phishing
// Class 1 = Legitimate

const PHISHING_CLASS = 0;
const LEGITIMATE_CLASS = 1;

// Phishing probability threshold
const PHISHING_THRESHOLD = 0.50;

let model = null;
let modelPromise = null;


// ==========================================
// WASM CONFIGURATION
// ==========================================

ort.env.wasm.wasmPaths = {
    mjs: chrome.runtime.getURL(
        "ort-wasm-simd-threaded.mjs"
    ),
    wasm: chrome.runtime.getURL(
        "ort-wasm-simd-threaded.wasm"
    )
};

ort.env.wasm.numThreads = 1;


// ==========================================
// LOAD ONNX MODEL
// ==========================================

async function loadModel() {

    if (model) {
        return model;
    }

    if (modelPromise) {
        return modelPromise;
    }

    modelPromise = (async () => {

        console.log("================================");
        console.log("Loading Final Random Forest ONNX Model");
        console.log("Model path:", MODEL_PATH);
        console.log("Expected features:", EXPECTED_FEATURES);
        console.log("================================");

        const response = await fetch(MODEL_PATH);

        if (!response.ok) {
            throw new Error(
                `Failed to load ONNX model. HTTP ${response.status}`
            );
        }

        const modelBuffer = await response.arrayBuffer();

        if (modelBuffer.byteLength === 0) {
            throw new Error("ONNX model file is empty.");
        }

        const loadedModel = await ort.InferenceSession.create(
            modelBuffer,
            {
                executionProviders: ["wasm"]
            }
        );

        console.log("MODEL INPUTS:", loadedModel.inputNames);
        console.log("MODEL OUTPUTS:", loadedModel.outputNames);

        if (!loadedModel.inputNames.includes("float_input")) {
            throw new Error(
                "Expected ONNX input 'float_input' was not found."
            );
        }

        if (!loadedModel.outputNames.includes("label")) {
            throw new Error(
                "Expected ONNX output 'label' was not found."
            );
        }

        if (!loadedModel.outputNames.includes("probabilities")) {
            throw new Error(
                "Expected ONNX output 'probabilities' was not found."
            );
        }

        model = loadedModel;

        console.log(
            "Final Random Forest ONNX model loaded successfully."
        );

        return model;

    })();

    try {

        return await modelPromise;

    } catch (error) {

        modelPromise = null;
        model = null;

        throw error;
    }
}


// ==========================================
// VALIDATE FEATURES
// ==========================================

function validateFeatures(features) {

    if (!Array.isArray(features)) {
        throw new Error(
            "Features must be an array."
        );
    }

    if (features.length !== EXPECTED_FEATURES) {
        throw new Error(
            `Expected ${EXPECTED_FEATURES} features, received ${features.length}.`
        );
    }

    const invalidIndex = features.findIndex(
        value =>
            typeof value !== "number" ||
            !Number.isFinite(value)
    );

    if (invalidIndex !== -1) {
        throw new Error(
            `Invalid feature value at index ${invalidIndex}.`
        );
    }

    return true;
}


// ==========================================
// EXTRACT CLASS PROBABILITIES
// ==========================================

function extractProbabilities(probabilityOutput) {

    if (
        !probabilityOutput ||
        !probabilityOutput.data
    ) {
        throw new Error(
            "ONNX probability output is missing."
        );
    }

    const raw = Array.from(
        probabilityOutput.data
    );

    console.log(
        "RAW PROBABILITY OUTPUT:",
        raw
    );

    if (raw.length !== 2) {
        throw new Error(
            `Expected 2 probabilities, received ${raw.length}.`
        );
    }

    // ONNX class order:
    // Index 0 = Phishing
    // Index 1 = Legitimate

    const phishingProbability = Number(
        raw[PHISHING_CLASS]
    );

    const legitimateProbability = Number(
        raw[LEGITIMATE_CLASS]
    );

    if (
        !Number.isFinite(phishingProbability) ||
        !Number.isFinite(legitimateProbability)
    ) {
        throw new Error(
            "ONNX returned invalid probability values."
        );
    }

    if (
        phishingProbability < 0 ||
        phishingProbability > 1 ||
        legitimateProbability < 0 ||
        legitimateProbability > 1
    ) {
        throw new Error(
            "ONNX probabilities are outside the 0–1 range."
        );
    }

    const total =
        phishingProbability +
        legitimateProbability;

    if (Math.abs(total - 1) > 0.001) {
        throw new Error(
            `Probabilities must sum to 1. Received: ${total}`
        );
    }

    return {
        phishingProbability,
        legitimateProbability
    };
}


// ==========================================
// RANDOM FOREST PREDICTION
// ==========================================

async function predict(features) {

    console.log(
        "PREDICT FUNCTION STARTED."
    );

    validateFeatures(features);

    const loadedModel = await loadModel();

    console.log(
        "FEATURE COUNT:",
        features.length
    );

    // Convert input to Float32Array
    const input = new Float32Array(features);

    // ONNX input tensor: [1, 30]
    const tensor = new ort.Tensor(
        "float32",
        input,
        [1, EXPECTED_FEATURES]
    );

    console.log(
        "RUNNING ONNX MODEL..."
    );

    const results = await loadedModel.run({
        float_input: tensor
    });

    console.log(
        "ONNX MODEL EXECUTION COMPLETED."
    );

    const labelOutput = results["label"];

    const probabilityOutput = results["probabilities"];

    if (
        !labelOutput ||
        !labelOutput.data ||
        labelOutput.data.length < 1
    ) {
        throw new Error(
            "ONNX label output is missing."
        );
    }

    const modelLabel = Number(
        labelOutput.data[0]
    );

    if (
        modelLabel !== PHISHING_CLASS &&
        modelLabel !== LEGITIMATE_CLASS
    ) {
        throw new Error(
            `Unexpected ONNX class label: ${modelLabel}`
        );
    }

    const {
        phishingProbability,
        legitimateProbability
    } = extractProbabilities(probabilityOutput);

    // Apply phishing threshold.
    // A URL is classified as phishing when its
    // phishing probability reaches the threshold.

    const prediction =
        phishingProbability >= PHISHING_THRESHOLD
            ? PHISHING_CLASS
            : LEGITIMATE_CLASS;

    const classification =
        prediction === PHISHING_CLASS
            ? "PHISHING"
            : "LEGITIMATE";

    console.log("================================");
    console.log("FINAL RANDOM FOREST PREDICTION");
    console.log("ONNX model label:", modelLabel);
    console.log("Final prediction:", prediction);
    console.log(
        "Phishing probability:",
        phishingProbability
    );
    console.log(
        "Legitimate probability:",
        legitimateProbability
    );
    console.log(
        "Threshold:",
        PHISHING_THRESHOLD
    );
    console.log(
        "Final classification:",
        classification
    );
    console.log("================================");

    return {
        prediction,
        modelLabel,
        phishingProbability,
        legitimateProbability,
        classification,
        threshold: PHISHING_THRESHOLD
    };
}


// ==========================================
// MESSAGE HANDLER
// ==========================================

chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {

        console.log(
            "OFFSCREEN RECEIVED MESSAGE:",
            message
        );

        if (
            !message ||
            message.type !== "PREDICT_URL_OFFSCREEN"
        ) {
            return false;
        }

        console.log(
            "OFFSCREEN: Processing prediction request."
        );

        (async () => {

            try {

                const features = message.features;

                validateFeatures(features);

                console.log(
                    "OFFSCREEN: Received feature count:",
                    features.length
                );

                const result = await predict(features);

                console.log(
                    "OFFSCREEN PREDICTION RESULT:",
                    result
                );

                const response = {
                    success: true,
                    ...result
                };

                sendResponse(response);

                console.log(
                    "OFFSCREEN RESPONSE SENT:",
                    response
                );

            } catch (error) {

                console.error(
                    "OFFSCREEN PREDICTION FAILED:",
                    error
                );

                sendResponse({
                    success: false,
                    error: error?.message || String(error)
                });
            }

        })();

        return true;
    }
);


// ==========================================
// INITIALIZE MODEL
// ==========================================

loadModel()

    .then(() => {

        console.log(
            "Final Random Forest phishing detection engine is ready."
        );

    })

    .catch(error => {

        console.error(
            "Failed to initialize ONNX model:",
            error
        );

    });


// ==========================================
// FIREFOX: let background.js call the model directly
// ==========================================

globalThis.pgPredictDirect = predict;

})();
