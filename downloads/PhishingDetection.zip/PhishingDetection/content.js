function showPhishingWarning(probability) {
  if (document.getElementById("phish-warning-overlay")) return;

  const overlay = document.createElement("div");
  overlay.id = "phish-warning-overlay";
  overlay.innerHTML = `
    <style>
      @keyframes vibrate { /* ilagay dito yung keyframes sa itaas */ }
      #phish-warning-overlay {
        position: fixed; inset: 0; z-index: 2147483647;
        background: rgba(120, 0, 0, 0.95);
        display: flex; flex-direction: column;
        align-items: center; justify-content: center;
        color: white; font-family: sans-serif; text-align: center;
      }
      #phish-warning-overlay .icon {
        font-size: 120px; display: inline-block;
        animation: vibrate 0.5s linear infinite;
      }
      #phish-warning-overlay button {
        margin: 8px; padding: 12px 24px; font-size: 16px;
        border: none; border-radius: 8px; cursor: pointer;
      }
    </style>
    <div class="icon">⚠️</div>
    <h1>Babala: Posibleng Phishing Website!</h1>
    <p>Phishing probability: ${probability}%</p>
    <button id="phish-back">Bumalik sa Ligtas na Pahina</button>
    <button id="phish-continue">Ituloy pa rin (hindi inirerekomenda)</button>
  `;
  document.documentElement.appendChild(overlay);

  document.getElementById("phish-back").onclick = () => history.back();
  document.getElementById("phish-continue").onclick = () => overlay.remove();
}

// Tatanggap ng mensahe mula sa popup/background
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "SHOW_WARNING") showPhishingWarning(msg.probability);
});