"use strict";

// ============================================
// PHISHING WEBSITE DETECTOR
// Random Forest ONNX
// 30 Features - Detection Speed Testing
// ============================================

// Chrome / Edge: service worker loads the helper files here.
// Firefox: manifest.json "background.scripts" already loads them.
if (typeof importScripts === "function") {
    importScripts(chrome.runtime.getURL("features.js"));
}

console.log("Feature extractor loaded:", typeof extractFeatures);

const PHISHING_THRESHOLD = 0.50;
// Verdict rule (full URL + website, both by the Random Forest) is in features.js -> decidePhishing()
const BLOCK_THRESHOLD = 0.50;
const EXPECTED_FEATURE_COUNT = 30;

const PHISHING_CLASS = 0;
const LEGITIMATE_CLASS = 1;

let creatingOffscreen = null;
let offscreenReady = null;

const checksInProgress = new Map();
const activeWarnings = new Map();

// ============================================
// URL VALIDATION
// ============================================

function isCheckableUrl(url) {
    if (typeof url !== "string") return false;

    try {
        const parsed = new URL(url);

        return (
            ["http:", "https:"].includes(parsed.protocol) &&
            Boolean(parsed.hostname)
        );
    } catch {
        return false;
    }
}

// ============================================
// FEATURE EXTRACTION
// ============================================

function getFeatureValues(url) {
    if (typeof extractFeatures !== "function") {
        throw new Error("Feature extractor is unavailable.");
    }

    const features = extractFeatures(url);

    if (!features || typeof features !== "object") {
        throw new Error("Could not extract URL features.");
    }

    const values = FEATURE_COLUMNS.map(name => features[name]);

    if (
        values.length !== EXPECTED_FEATURE_COUNT ||
        values.some(value =>
            typeof value !== "number" ||
            !Number.isFinite(value)
        )
    ) {
        throw new Error("Invalid 30-feature input.");
    }

    console.log("URL checked:", new URL(url).hostname);
    console.log("Extracted feature count:", values.length);

    return values;
}

// ============================================
// OFFSCREEN DOCUMENT
// ============================================

async function setupOffscreenDocument() {
    if (offscreenReady) return offscreenReady;

    if (creatingOffscreen) {
        await creatingOffscreen;
    }

    offscreenReady = (async () => {
        const offscreenUrl =
            chrome.runtime.getURL("offscreen.html");

        const contexts = await chrome.runtime.getContexts({
            contextTypes: ["OFFSCREEN_DOCUMENT"],
            documentUrls: [offscreenUrl]
        });

        if (contexts.length > 0) {
            console.log("Offscreen document already exists.");
            return;
        }

        creatingOffscreen = chrome.offscreen.createDocument({
            url: "offscreen.html",
            reasons: ["WORKERS"],
            justification:
                "Run the Random Forest ONNX phishing detection model."
        });

        try {
            await creatingOffscreen;

            console.log("Offscreen document created successfully.");

        } finally {
            creatingOffscreen = null;
        }
    })();

    try {
        await offscreenReady;
    } catch (error) {
        offscreenReady = null;
        creatingOffscreen = null;
        throw error;
    }

    return offscreenReady;
}

// ============================================
// ONNX PREDICTION
// ============================================

async function sendToOffscreen(featureValues) {
    if (
        !Array.isArray(featureValues) ||
        featureValues.length !== EXPECTED_FEATURE_COUNT ||
        featureValues.some(value =>
            typeof value !== "number" ||
            !Number.isFinite(value)
        )
    ) {
        throw new Error("Invalid ONNX model input.");
    }

    // Firefox: the model runs in this background page (offscreen.js is loaded
    // by manifest.json), so it is called directly
    if (typeof globalThis.pgPredictDirect === "function") {
        const result = await globalThis.pgPredictDirect(featureValues);
        return { success: true, ...result };
    }

    // Chrome / Edge: the model runs in the offscreen document
    await setupOffscreenDocument();

    const response = await chrome.runtime.sendMessage({
        type: "PREDICT_URL_OFFSCREEN",
        features: featureValues
    });

    if (!response || response.success !== true) {
        throw new Error(
            response?.error || "ONNX prediction failed."
        );
    }

    return response;
}

// ============================================
// PREDICTION VALIDATION
// ============================================

function validatePrediction(response) {
    const phishingProbability =
        Number(response?.phishingProbability);

    const legitimateProbability =
        Number(response?.legitimateProbability);

    const modelLabel = Number(response?.modelLabel);

    if (
        !Number.isFinite(phishingProbability) ||
        !Number.isFinite(legitimateProbability) ||
        phishingProbability < 0 ||
        phishingProbability > 1 ||
        legitimateProbability < 0 ||
        legitimateProbability > 1
    ) {
        throw new Error("Invalid prediction probabilities.");
    }

    if (
        Math.abs(
            phishingProbability + legitimateProbability - 1
        ) > 0.01
    ) {
        throw new Error("Invalid probability sum.");
    }

    if (
        !Number.isInteger(modelLabel) ||
        ![PHISHING_CLASS, LEGITIMATE_CLASS].includes(modelLabel)
    ) {
        throw new Error("Invalid model label.");
    }

    const prediction =
        phishingProbability >= PHISHING_THRESHOLD
            ? PHISHING_CLASS
            : LEGITIMATE_CLASS;

    const result = {
        prediction,
        modelLabel,
        phishingProbability,
        legitimateProbability,
        classification:
            prediction === PHISHING_CLASS
                ? "PHISHING"
                : "LEGITIMATE"
    };

    console.log("Model result:", result);
    console.log("Detection threshold:", PHISHING_THRESHOLD);

    return result;
}

// ============================================
// WARNING PAGE
// ============================================

// ============================================
// RESPONSE TIME LOG (for the Table 1 target: average <= 2.0 seconds)
// Saves how long each automatic check took, on this device only.
// ============================================

const TIMINGS_KEY = "pgResponseTimes";

async function saveTiming(url, ms, isPhishing) {
    try {
        const data = await chrome.storage.local.get(TIMINGS_KEY);
        const list = Array.isArray(data[TIMINGS_KEY]) ? data[TIMINGS_KEY] : [];
        let host = url;
        try { host = new URL(url).hostname; } catch { /* keep url */ }

        // the same page can be checked twice (before and after it starts loading);
        // only the first check of a visit is counted
        const last = list[list.length - 1];
        if (last && last.website === host && Date.now() - last.time < 5000) return;

        list.push({
            website: host,
            ms: Number(ms.toFixed(2)),
            verdict: isPhishing ? "PHISHING" : "LEGITIMATE",
            time: Date.now()
        });
        await chrome.storage.local.set({ [TIMINGS_KEY]: list.slice(-500) });
    } catch (error) {
        console.warn("Response time not saved:", error.message);
    }
}

async function showWarningPage(tabId, url, probability, detectionMs, realDestination) {
    const warningUrl = new URL(
        chrome.runtime.getURL("warning.html")
    );

    warningUrl.searchParams.set("url", url);

    // short link: also show where it really goes
    if (realDestination && realDestination !== url) {
        warningUrl.searchParams.set("dest", realDestination);
    }

    warningUrl.searchParams.set(
        "probability",
        String(probability)
    );

    // detection time is shown in the Random Forest popup
    if (Number.isFinite(detectionMs)) {
        warningUrl.searchParams.set("ms", detectionMs.toFixed(0));
    }

    activeWarnings.set(tabId, { url, time: Date.now() });

    await chrome.tabs.update(tabId, {
        url: warningUrl.href
    });
}

// ============================================
// MANUAL PREDICTION
// ============================================

chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
        if (!message) return false;

        if (message.type === "PREDICT_URL") {
            (async () => {
                try {
                    const features = message.features;

                    if (
                        !Array.isArray(features) ||
                        features.length !== EXPECTED_FEATURE_COUNT ||
                        features.some(value =>
                            typeof value !== "number" ||
                            !Number.isFinite(value)
                        )
                    ) {
                        throw new Error("Expected 30 numeric features.");
                    }

                    const startTime = performance.now();

                    const response =
                        await sendToOffscreen(features);

                    const result =
                        validatePrediction(response);

                    const processingTime =
                        performance.now() - startTime;

                    console.log(
                        `MANUAL PREDICTION TIME: ${processingTime.toFixed(2)} ms`
                    );

                    sendResponse({
                        success: true,
                        ...result,
                        threshold: PHISHING_THRESHOLD,
                        processingTimeMs: Number(
                            processingTime.toFixed(2)
                        )
                    });

                } catch (error) {
                    console.error("Manual prediction failed:", error);

                    sendResponse({
                        success: false,
                        error: error.message
                    });
                }
            })();

            return true;
        }

        if (message.type === "ALLOW_URL_ONCE") {
            (async () => {
                try {
                    const tabId = sender.tab?.id;
                    const url = message.url;

                    if (
                        tabId === undefined ||
                        !isCheckableUrl(url)
                    ) {
                        throw new Error("Invalid tab or URL.");
                    }

                    await chrome.storage.session.set({
                        [`allowOnce_${tabId}`]: { url }
                    });

                    sendResponse({ success: true });

                } catch (error) {
                    sendResponse({
                        success: false,
                        error: error.message
                    });
                }
            })();

            return true;
        }

        return false;
    }
);

// ============================================
// AUTOMATIC URL CHECKING + SPEED TEST
// BAGO: checked BEFORE the page loads (onBeforeNavigate),
// so typing a URL in the address bar or clicking a link
// goes straight to warning.html when it is phishing.
// ============================================

const resultCache = new Map();          // url -> prediction result (faster repeat checks)
const MAX_CACHE = 500;

function normalizeForCompare(url) {
    try {
        const u = new URL(url);
        u.hash = "";
        return u.href;
    } catch {
        return String(url);
    }
}

function sameUrl(a, b) {
    return normalizeForCompare(a) === normalizeForCompare(b);
}

async function predictWithCache(url) {
    const key = normalizeForCompare(url);

    if (resultCache.has(key)) {
        return resultCache.get(key);
    }

    const features = getFeatureValues(url);
    const response = await sendToOffscreen(features);
    const result = validatePrediction(response);

    if (resultCache.size >= MAX_CACHE) {
        resultCache.delete(resultCache.keys().next().value);
    }
    resultCache.set(key, result);

    return result;
}

// ---- Find where a short link really goes (bit.ly -> real website) ----
// Only reads the final address; the page is not opened or shown,
// cookies are not sent, and the download stops right away.
const REDIRECT_TIMEOUT_MS = 3000;

async function resolveRedirect(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REDIRECT_TIMEOUT_MS);

    try {
        const response = await fetch(url, {
            method: "GET",
            redirect: "follow",
            credentials: "omit",
            cache: "no-store",
            signal: controller.signal
        });
        const finalUrl = response.url || url;
        console.log("Redirect check:", response.status, finalUrl);
        controller.abort();               // stop downloading the page itself
        return isCheckableUrl(finalUrl) ? finalUrl : url;
    } catch (error) {
        console.warn("Could not follow the link:", error.name, error.message);
        return url;                       // keep the first result
    } finally {
        clearTimeout(timer);
    }
}

// A short code link: one short part after the website, no query
// e.g. https://bit.ly/4zCdbeV  https://t.co/Ab12Cd34Ef
// (this checks the SHAPE of the link, not a list of websites)
function looksLikeShortCode(url) {
    try {
        const u = new URL(url);
        const parts = u.pathname.split("/").filter(Boolean);
        return !u.search && parts.length === 1 && /^[A-Za-z0-9_-]{3,16}$/.test(parts[0]);
    } catch {
        return false;
    }
}

// ---- Settings from the popup (Auto Scan, Notifications) ----
let settingsCache = null;

async function getSettings() {
    if (!settingsCache) settingsCache = await loadSettings();
    return settingsCache;
}

chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[SETTINGS_KEY]) {
        settingsCache = { ...DEFAULT_SETTINGS, ...(changes[SETTINGS_KEY].newValue || {}), threshold: DEFAULT_SETTINGS.threshold };
    }
});

function notifyBlocked(url, probability) {
    let host = url;
    try { host = new URL(url).hostname; } catch { /* keep url */ }
    try {
        chrome.notifications.create({
            type: "basic",
            iconUrl: chrome.runtime.getURL("icons/icon128.png"),
            title: "GRJD Shield: Phishing website blocked",
            message: `${host} (${(probability * 100).toFixed(2)}% phishing)`,
            priority: 2
        });
    } catch (error) {
        console.warn("Notification failed:", error.message);
    }
}

async function checkNavigation(tabId, url, source) {
    if (!isCheckableUrl(url)) return;

    const settings = await getSettings();
    if (!settings.autoScan) return;   // Settings > Auto Scan is off

    const totalStartTime = performance.now();
    const key = `allowOnce_${tabId}`;

    try {
        // ---- User clicked "Continue" on the warning page ----
        // The approval stays valid while the tab is on that same URL
        // (so onBeforeNavigate AND onCommitted both let it through).
        const stored = await chrome.storage.session.get(key);
        const approval = stored[key];

        if (approval && sameUrl(approval.url, url)) {
            activeWarnings.delete(tabId);
            console.log("User-approved URL.");
            return;
        }

        if (approval) {
            // the user went to a different URL -> approval ends
            await chrome.storage.session.remove(key);
        }

        // ---- Avoid double checks (onBeforeNavigate + onCommitted fire for the same URL) ----
        if (checksInProgress.get(tabId) === normalizeForCompare(url)) {
            return;
        }

        const warned = activeWarnings.get(tabId);
        if (warned && sameUrl(warned.url, url) && Date.now() - warned.time < 3000) {
            return;
        }

        // PANEL: "wag mag-base sa database" -> walang whitelist.
        // Random Forest ang nagpapasya sa LAHAT ng URL, luma man o bago.

        checksInProgress.set(tabId, normalizeForCompare(url));

        const processingStartTime = performance.now();

        console.log(`Checking URL with Random Forest (${source}).`);

        // the Random Forest checks the full URL and its website (features.js)
        const firstCheck =
            await checkUrlWithModel(url, predictWithCache, settings.threshold);
        const { full: fullResult, domainProbability } = firstCheck;
        let decision = firstCheck.decision;
        let realDestination = null;

        console.log(
            `Full URL: ${(fullResult.phishingProbability * 100).toFixed(2)}% | ` +
            `Website: ${(domainProbability * 100).toFixed(2)}% | ` +
            `Verdict: ${decision.isPhishing ? "PHISHING" : "LEGITIMATE"} (${decision.basis})`
        );

        // ---- Short links (bit.ly, tinyurl, t.co, ...) ----
        // The website itself is legitimate but the link hides where it goes.
        // Find the real destination and let the Random Forest check THAT URL.
        // No list of shorteners: this runs for any link with this result.
        if (decision.isPhishing && domainProbability < SITE_OK_LIMIT) {
            const destination = await resolveRedirect(url);
            if (destination !== url) realDestination = destination;

            if (destination !== url && siteKeyOf(destination) !== siteKeyOf(url)) {
                console.log("Link redirects to:", destination);

                const target = await checkUrlWithModel(
                    destination, predictWithCache, settings.threshold
                );
                decision = { ...target.decision, basis: "destination" };

                console.log(
                    `Destination: ${decision.isPhishing ? "PHISHING" : "LEGITIMATE"} ` +
                    `(${(decision.score * 100).toFixed(2)}%)`
                );
            } else if (domainProbability < SITE_TRUST_LIMIT && looksLikeShortCode(url)) {
                // The link service did not give the destination here
                // (e.g. it answered 410 / showed its own page). The website is
                // clearly legitimate, so let the browser open it: the REAL page
                // is checked by the Random Forest as soon as the browser gets there
                // (onCommitted), and blocked if it is phishing.
                decision = { isPhishing: false, score: decision.score, basis: "short link" };
                console.log(
                    "Short link on a legitimate website. " +
                    "The real page will be checked when it opens."
                );
            }
        }

        const processingTime =
            performance.now() - processingStartTime;

        console.log(
            `PROCESSING TIME: ${processingTime.toFixed(2)} ms`
        );

        // ---- Make sure the user is still going to this URL ----
        let currentTab;

        try {
            currentTab = await chrome.tabs.get(tabId);
        } catch {
            return;
        }

        // Before the page loads, the new address is in pendingUrl, not url.
        const stillHere =
            sameUrl(currentTab.pendingUrl || "", url) ||
            sameUrl(currentTab.url || "", url);

        if (!stillHere) {
            console.log("Outdated prediction ignored.");
            return;
        }

        const totalDetectionTime =
            performance.now() - totalStartTime;

        console.log(
            `TOTAL DETECTION TIME: ${totalDetectionTime.toFixed(2)} ms`
        );

        void saveTiming(url, totalDetectionTime, decision.isPhishing);

        if (decision.isPhishing) {
            console.warn(
                "POTENTIAL PHISHING DETECTED. Blocking.",
                decision.score
            );

            await showWarningPage(
                tabId,
                url,
                decision.score,
                totalDetectionTime,
                realDestination
            );

            if (settings.notifications) notifyBlocked(url, decision.score);

        } else {
            console.log(
                "URL classified as LEGITIMATE.",
                1 - decision.score
            );

            activeWarnings.delete(tabId);
        }

    } catch (error) {
        console.error(
            "Automatic URL checking failed:",
            error.message
        );

    } finally {
        if (checksInProgress.get(tabId) === normalizeForCompare(url)) {
            checksInProgress.delete(tabId);
        }
    }
}

// ============================================
// NAVIGATION LISTENERS
// ============================================

// 1) BEFORE the page loads: typed in the address bar, clicked a link,
//    opened a bookmark, opened a link in a new tab, etc.
chrome.webNavigation.onBeforeNavigate.addListener(details => {
    if (details.frameId !== 0) return;

    void checkNavigation(details.tabId, details.url, "before navigate");
});

// 2) AFTER commit: catches server redirects (e.g. short links like bit.ly
//    that redirect to the real phishing page) and anything missed above.
chrome.webNavigation.onCommitted.addListener(details => {
    if (details.frameId !== 0) return;

    void checkNavigation(details.tabId, details.url, "committed");
});

// 3) Pages that change URL without reloading (single-page apps).
chrome.webNavigation.onHistoryStateUpdated.addListener(details => {
    if (details.frameId !== 0) return;

    void checkNavigation(details.tabId, details.url, "history update");
});

// 4) Backup: Chrome sometimes pre-loads (prerenders) a URL typed in the
//    address bar; when it is shown, the tab URL changes here.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (!changeInfo.url) return;

    void checkNavigation(tabId, changeInfo.url, "tab updated");
});

// ============================================
// LOAD THE MODEL EARLY (so the first check is fast)
// ============================================

async function warmUpModel() {
    try {
        await setupOffscreenDocument();
        await sendToOffscreen(getFeatureValues("https://example.com/"));
        console.log("Model warmed up.");
    } catch (error) {
        console.warn("Model warm-up failed:", error.message);
    }
}

chrome.runtime.onStartup.addListener(() => {
    void warmUpModel();
});

// ============================================
// CERTIFICATE ERROR LOGGING
// ============================================

chrome.webNavigation.onErrorOccurred.addListener(details => {
    if (details.frameId !== 0) return;

    if (
        details.error &&
        details.error.toLowerCase().includes("cert")
    ) {
        console.warn(
            "Browser certificate/navigation error:",
            details.error
        );

        console.warn(
            "Chrome security protection remains active."
        );
    }
});

// ============================================
// TAB CLEANUP
// ============================================

chrome.tabs.onRemoved.addListener(tabId => {
    checksInProgress.delete(tabId);
    activeWarnings.delete(tabId);

    void chrome.storage.session
        .remove(`allowOnce_${tabId}`)
        .catch(error => {
            console.warn("Tab cleanup failed:", error.message);
        });
});

// ============================================
// INSTALLATION
// ============================================

chrome.runtime.onInstalled.addListener(async details => {
    console.log(
        "GRJD Shield:",
        details.reason
    );

    // the "Always allow" feature was removed: delete its old saved list
    try { await chrome.storage.local.remove("pgUserAllowedSites"); } catch { /* ignore */ }

    try {
        // Firefox has no offscreen documents, nothing to refresh
        if (chrome.offscreen) {
            const offscreenUrl =
                chrome.runtime.getURL("offscreen.html");

            const contexts = await chrome.runtime.getContexts({
                contextTypes: ["OFFSCREEN_DOCUMENT"],
                documentUrls: [offscreenUrl]
            });

            if (contexts.length > 0) {
                await chrome.offscreen.closeDocument();
            }
        }

        offscreenReady = null;
        creatingOffscreen = null;

    } catch (error) {
        console.error("Offscreen refresh failed:", error);
    }

    void warmUpModel();
});

console.log(
    "GRJD Shield background service worker loaded."
);