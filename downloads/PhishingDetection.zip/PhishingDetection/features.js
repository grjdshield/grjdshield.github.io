
"use strict";

// ============================================
// PHISHING DETECTOR - FEATURE EXTRACTION
// 30 FEATURES - RANDOM FOREST ONNX
//
// IMPORTANT: This is a line-by-line port of the Google Colab notebook
// (Random_Phishing_Training.ipynb, CELL 4 + CELL 4.1).
// The model only works correctly if every feature here is computed
// EXACTLY like in Python. If you change the notebook, change this too.
// ============================================

const FEATURE_COLUMNS = [
    "url_length",
    "has_ip_address",
    "dot_count",
    "https_flag",
    "url_entropy",
    "token_count",
    "subdomain_count",
    "query_param_count",
    "tld_length",
    "path_length",
    "path_digit_count",
    "has_hyphen_in_domain",
    "number_of_digits",
    "tld_popularity",
    "suspicious_file_extension",
    "domain_name_length",
    "percentage_numeric_chars",
    "domain_entropy",
    "domain_digit_count",
    "domain_digit_ratio",
    "domain_hyphen_count",
    "domain_letter_ratio",
    "domain_vowel_ratio",
    "max_consecutive_digits",
    "max_consecutive_same_char",
    "query_length",
    "fragment_flag",
    "at_symbol_flag",
    "punycode_flag",
    "port_flag"
];

// ============================================
// POPULAR TLDs  (notebook: popular_tlds)
// ============================================

const POPULAR_TLDS = new Set([
    "com", "org", "net", "edu", "gov", "mil",
    "ph", "uk", "us", "ca", "au", "de", "jp",
    "in", "io", "co", "info", "biz", "me"
]);

// ============================================
// SUSPICIOUS FILE EXTENSIONS  (notebook: suspicious_extensions)
// ============================================

const SUSPICIOUS_EXTENSIONS = [
    ".exe", ".scr", ".bat", ".cmd", ".js",
    ".jar", ".vbs", ".msi", ".php"
];

// ============================================
// PYTHON-COMPATIBLE HELPERS
// Python counts characters (code points), so we do the same.
// ============================================

const chars = text => Array.from(text);          // Python: list(text)
const pyLen = text => chars(text).length;        // Python: len(text)
const isDigit = ch => /\p{Nd}/u.test(ch);         // Python: str.isdigit()
const isAlpha = ch => /\p{L}/u.test(ch);          // Python: str.isalpha()

function countWhere(text, test) {
    let n = 0;
    for (const ch of text) if (test(ch)) n++;
    return n;
}

function countSubstring(text, sub) {             // Python: text.count(sub)
    return text.split(sub).length - 1;
}

// ============================================
// URL PARSING - same result as Python urllib.parse.urlparse()
// (NOT the browser's new URL(), which changes the URL: adds "/",
//  lowercases, percent-encodes... and gives different features)
// ============================================

function pyUrlParse(url) {
    let rest = url;
    let scheme = "";

    const schemeMatch = rest.match(/^([A-Za-z][A-Za-z0-9+.\-]*):/);
    if (schemeMatch) {
        scheme = schemeMatch[1].toLowerCase();
        rest = rest.slice(schemeMatch[0].length);
    }

    let netloc = "";
    if (rest.startsWith("//")) {
        rest = rest.slice(2);
        const end = rest.search(/[/?#]/);
        netloc = end === -1 ? rest : rest.slice(0, end);
        rest = end === -1 ? "" : rest.slice(end);
    }

    let fragment = "";
    const hashIndex = rest.indexOf("#");
    if (hashIndex !== -1) {
        fragment = rest.slice(hashIndex + 1);
        rest = rest.slice(0, hashIndex);
    }

    let query = "";
    const queryIndex = rest.indexOf("?");
    if (queryIndex !== -1) {
        query = rest.slice(queryIndex + 1);
        rest = rest.slice(0, queryIndex);
    }

    // urlparse() also splits ";params" off the last path segment
    let path = rest;
    const lastSlash = path.lastIndexOf("/");
    const semi = path.indexOf(";", lastSlash === -1 ? 0 : lastSlash);
    if (semi !== -1) path = path.slice(0, semi);

    return { scheme, netloc, path, query, fragment };
}

// Python: parsed.port  (None when missing or invalid)
function pyPort(netloc) {
    const hostinfo = netloc.split("@").pop();
    let portText = "";

    if (hostinfo.startsWith("[")) {
        const close = hostinfo.indexOf("]");
        const after = close === -1 ? "" : hostinfo.slice(close + 1);
        if (after.startsWith(":")) portText = after.slice(1);
    } else {
        const colon = hostinfo.indexOf(":");
        if (colon !== -1) portText = hostinfo.slice(colon + 1);
    }

    if (!/^\d+$/.test(portText)) return null;
    const port = Number(portText);
    return port <= 65535 ? port : null;
}

// Python: len(parse_qs(query))  -> unique keys that have a non-empty value
function pyParseQsCount(query) {
    if (!query) return 0;

    const decode = text => {
        try {
            return decodeURIComponent(text.replace(/\+/g, " "));
        } catch {
            return text.replace(/\+/g, " ");
        }
    };

    const keys = new Set();
    for (const part of query.split("&")) {
        if (!part) continue;
        const eq = part.indexOf("=");
        if (eq === -1) continue;                       // no "=" -> skipped
        const value = decode(part.slice(eq + 1));
        if (value === "") continue;                    // blank value -> skipped
        keys.add(decode(part.slice(0, eq)));
    }
    return keys.size;
}

// ============================================
// ENTROPY  (notebook: calculate_entropy)
// ============================================

function calculateEntropy(text) {
    if (!text) {
        return 0;
    }

    const counts = new Map();
    for (const ch of text) {
        counts.set(ch, (counts.get(ch) || 0) + 1);
    }

    const length = pyLen(text);
    let entropy = 0;

    for (const count of counts.values()) {
        const probability = count / length;
        entropy -= probability * Math.log2(probability);
    }

    return entropy;
}

// ============================================
// MAXIMUM CONSECUTIVE DIGITS  (notebook: max_consecutive)
// ============================================

function maxConsecutiveDigits(text) {
    let maximum = 0;
    let current = 0;

    for (const ch of text) {
        if (isDigit(ch)) {
            current++;
            maximum = Math.max(maximum, current);
        } else {
            current = 0;
        }
    }

    return maximum;
}

// ============================================
// LONGEST SAME-CHARACTER RUN  (notebook CELL 4.1: longest_same_char_run)
// ============================================

function longestSameCharRun(text) {
    const list = chars(text);
    if (!list.length) {
        return 0;
    }

    let maximum = 1;
    let current = 1;

    for (let i = 1; i < list.length; i++) {
        if (list[i] === list[i - 1]) {
            current++;
            maximum = Math.max(maximum, current);
        } else {
            current = 1;
        }
    }

    return maximum;
}

// ============================================
// MAIN FEATURE EXTRACTION  (notebook: extract_features)
// ============================================

function extractFeatures(rawUrl) {
    const url = String(rawUrl).trim();

    if (!url) {
        throw new Error(
            "URL could not be parsed; feature extraction stopped."
        );
    }

    const parsed = pyUrlParse(url.includes("://") ? url : "http://" + url);

    const domain = parsed.netloc.toLowerCase().split("@").pop().split(":")[0];
    const path = parsed.path;
    const query = parsed.query;
    const fragment = parsed.fragment;

    const tld = domain.includes(".") ? domain.split(".").pop() : "";

    const domainLength = pyLen(domain);
    const domainDigits = countWhere(domain, isDigit);
    const domainLetters = countWhere(domain, isAlpha);
    const domainVowels = countWhere(domain, ch => "aeiou".includes(ch));

    const urlLength = pyLen(url);
    const urlDigits = countWhere(url, isDigit);
    const port = pyPort(parsed.netloc);

    const values = {
        url_length: urlLength,

        has_ip_address: /(?:\d{1,3}\.){3}\d{1,3}/.test(domain) ? 1 : 0,

        dot_count: countSubstring(url, "."),

        https_flag: parsed.scheme === "https" ? 1 : 0,

        url_entropy: calculateEntropy(url),

        // notebook: len(re.findall(r"[./?&=_-]", url))
        token_count: (url.match(/[./?&=_-]/g) || []).length,

        subdomain_count: Math.max(0, domain.split(".").length - 2),

        query_param_count: pyParseQsCount(query),

        tld_length: pyLen(tld),

        path_length: pyLen(path),

        path_digit_count: countWhere(path, isDigit),

        has_hyphen_in_domain: domain.includes("-") ? 1 : 0,

        number_of_digits: urlDigits,

        tld_popularity: POPULAR_TLDS.has(tld) ? 1 : 0,

        suspicious_file_extension:
            SUSPICIOUS_EXTENSIONS.some(ext =>
                path.toLowerCase().endsWith(ext)
            ) ? 1 : 0,

        // notebook: domain_length = len(domain)  (full domain, with TLD)
        domain_name_length: domainLength,

        // notebook: digits / len(url) * 100
        percentage_numeric_chars:
            urlLength ? (urlDigits / urlLength) * 100 : 0,

        domain_entropy: calculateEntropy(domain),

        domain_digit_count: domainDigits,

        domain_digit_ratio:
            domainLength ? domainDigits / domainLength : 0,

        domain_hyphen_count: countSubstring(domain, "-"),

        domain_letter_ratio:
            domainLength ? domainLetters / domainLength : 0,

        // notebook: vowels / domain_length
        domain_vowel_ratio:
            domainLength ? domainVowels / domainLength : 0,

        max_consecutive_digits: maxConsecutiveDigits(url),

        max_consecutive_same_char: longestSameCharRun(url.toLowerCase()),

        query_length: pyLen(query),

        fragment_flag: fragment ? 1 : 0,

        // notebook: "@" in url  (anywhere in the URL)
        at_symbol_flag: url.includes("@") ? 1 : 0,

        punycode_flag: domain.includes("xn--") ? 1 : 0,

        port_flag: port ? 1 : 0
    };

    return values;
}

// ============================================
// FEATURE ARRAY FOR ONNX
// ============================================

function extractFeatureArray(url) {
    const features = extractFeatures(url);

    const values = FEATURE_COLUMNS.map(
        column => features[column]
    );

    if (
        values.length !== 30 ||
        values.some(value =>
            typeof value !== "number" ||
            !Number.isFinite(value)
        )
    ) {
        throw new Error(
            "Expected exactly 30 valid numeric features."
        );
    }

    return values;
}

// ============================================
// FINAL DECISION: the Random Forest checks up to three forms of the URL
//
//   1. FULL URL         https://getstarted.tiktok.com/ads?utm_source=fb&fbclid=IwY2...
//   2. WEBSITE only     https://getstarted.tiktok.com/
//   3. URL without the  https://getstarted.tiktok.com/ads
//      query part       (removes ad/tracking codes such as utm_, fbclid, gclid)
//
//   LEGITIMATE if the full URL is below 0.50
//   LEGITIMATE if the website is clearly legitimate (< 0.10)
//              and the full URL is not extremely suspicious (< 0.995)
//              -> long links with random IDs on normal websites
//                 (Facebook posts, Google Docs, YouTube, Drive)
//   LEGITIMATE if the URL without its query part is clearly legitimate (< 0.20)
//              and the website looks legitimate (< 0.30)
//              -> normal links that only carry long ad/tracking codes
//   PHISHING   otherwise
//
// All checks are made by the same Random Forest model. There is no whitelist,
// no blacklist and no database. The limits were chosen on the validation set
// and on new legitimate links that are not in the dataset.
// ============================================

const URL_THRESHOLD = 0.50;          // full URL: phishing probability limit
const SITE_TRUST_LIMIT = 0.11;       // website below this = clearly legitimate website
const URL_VERY_HIGH = 0.995;         // full URL at or above this = phishing even on a normal website
const CORE_TRUST_LIMIT = 0.35;       // URL without query below this = clearly legitimate link
const SITE_OK_LIMIT = 0.22;          // website must also be below this for check 3
const CORE_VERY_SAFE = 0.10;         // URL without query is clearly legitimate...
const SITE_FAIR_LIMIT = 0.40;        // ...and the website is not suspicious

// "https://web.facebook.com/user/posts/123?x=1" -> "https://web.facebook.com/"
function getSiteUrl(url) {
    try {
        const u = new URL(String(url).trim());
        return u.protocol + "//" + u.host + "/";
    } catch {
        return null;
    }
}

// "https://site.com/page?utm_source=fb#top" -> "https://site.com/page"
function getCoreUrl(url) {
    try {
        const u = new URL(String(url).trim());
        return u.protocol + "//" + u.host + (u.pathname || "/");
    } catch {
        return null;
    }
}

// Runs the Random Forest on the URL (and, only when needed, on its other forms) and decides.
//   predict(url) must return { phishingProbability, ... } (background.js / popup.js)
function withoutFragment(url) {
    try {
        const u = new URL(url);
        u.hash = "";
        return u.href;
    } catch {
        return url;
    }
}

async function checkUrlWithModel(url, predict, threshold) {
    // The part after "#" (e.g. #download) only moves to a spot on the same
    // page and is never sent to the website, so it is not checked.
    url = withoutFragment(url);

    const full = await predict(url);
    let siteProbability = full.phishingProbability;
    let coreProbability = full.phishingProbability;

    if (full.phishingProbability >= URL_THRESHOLD) {
        try {
            const siteUrl = getSiteUrl(url);
            if (siteUrl && siteUrl !== url) {
                siteProbability = (await predict(siteUrl)).phishingProbability;
            }
            const coreUrl = getCoreUrl(url);
            if (coreUrl && coreUrl !== url && coreUrl !== siteUrl) {
                coreProbability = (await predict(coreUrl)).phishingProbability;
            } else if (coreUrl === siteUrl) {
                coreProbability = siteProbability;
            }
        } catch {
            // keep the full URL result only
        }
    }

    const decision = decidePhishing(full.phishingProbability, siteProbability, threshold, coreProbability);
    return { full, domainProbability: siteProbability, coreProbability, decision };
}

// returns { isPhishing, score, basis }
//   score = full URL phishing probability (shown in the UI)
function decidePhishing(fullProbability, siteProbability, threshold, coreProbability) {
    const t = typeof threshold === "number" ? threshold : URL_THRESHOLD;
    const full = Number(fullProbability) || 0;
    const site = Number(siteProbability);
    const core = Number(coreProbability);

    if (full < t) {
        return { isPhishing: false, score: full, basis: "url" };
    }
    if (Number.isFinite(site) && site < SITE_TRUST_LIMIT && full < URL_VERY_HIGH) {
        return { isPhishing: false, score: full, basis: "website" };
    }
    if (Number.isFinite(core) && Number.isFinite(site) && core < CORE_TRUST_LIMIT && site < SITE_OK_LIMIT) {
        return { isPhishing: false, score: full, basis: "link" };
    }
    if (Number.isFinite(core) && Number.isFinite(site) && core < CORE_VERY_SAFE && site < SITE_FAIR_LIMIT) {
        return { isPhishing: false, score: full, basis: "link" };
    }
    return { isPhishing: true, score: full, basis: "url" };
}

// website name of a URL (used to see if a short link goes to another website)
function siteKeyOf(url) {
    try {
        return new URL(String(url).trim()).hostname.toLowerCase();
    } catch {
        return "";
    }
}

// ============================================
// SETTINGS (popup Settings page) - saved in chrome.storage.local
// ============================================

const SETTINGS_KEY = "pgSettings";

const DEFAULT_SETTINGS = {
    threshold: 0.50,        // fixed detection threshold (not shown in Settings)
    notifications: true,    // show a notification when a website is blocked
    autoScan: true          // check every website automatically (block before it loads)
};

async function loadSettings() {
    try {
        const data = await chrome.storage.local.get(SETTINGS_KEY);
        // threshold is always 0.50 (removed from Settings)
        return { ...DEFAULT_SETTINGS, ...(data[SETTINGS_KEY] || {}), threshold: DEFAULT_SETTINGS.threshold };
    } catch {
        return { ...DEFAULT_SETTINGS };
    }
}

async function saveSettings(settings) {
    await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
}

// ============================================
// GLOBAL EXPORTS
// ============================================

globalThis.FEATURE_COLUMNS = FEATURE_COLUMNS;
globalThis.extractFeatures = extractFeatures;
globalThis.extractFeatureArray = extractFeatureArray;
globalThis.checkUrlWithModel = checkUrlWithModel;
globalThis.getSiteUrl = getSiteUrl;
globalThis.getCoreUrl = getCoreUrl;
globalThis.siteKeyOf = siteKeyOf;
globalThis.decidePhishing = decidePhishing;
globalThis.SETTINGS_KEY = SETTINGS_KEY;
globalThis.DEFAULT_SETTINGS = DEFAULT_SETTINGS;
globalThis.loadSettings = loadSettings;
globalThis.saveSettings = saveSettings;

console.log("Feature extractor loaded:", typeof extractFeatures);
console.log("Feature count:", FEATURE_COLUMNS.length);
