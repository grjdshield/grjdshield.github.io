"use strict";

// =====================================================================
// PHISHING DETECTOR POPUP
//  Home     : URL check of the open tab (Random Forest, full URL + domain)
//  Scan     : every link inside the website + page content
//  History  : saved scans (5 per page)
//  Manual   : type any URL and check it
//  Settings : notifications, auto scan
// =====================================================================

const MAX_LINKS_TO_SCAN = 300;
const HISTORY_KEY = "scanHistory";
const MAX_HISTORY = 50;
const HISTORY_PAGE_SIZE = 5;

const BRANDS = ["paypal", "google", "facebook", "instagram", "microsoft", "apple", "amazon", "netflix",
    "gcash", "paymaya", "bdo", "bpi", "metrobank", "landbank", "shopee", "lazada", "whatsapp",
    "youtube", "linkedin", "dropbox", "steam", "discord", "tiktok"];
const SECOND_LEVEL = new Set(["com", "co", "org", "net", "gov", "edu", "ac"]);

// ---------- helpers ----------
function hostOf(u) { try { return new URL(u).hostname.toLowerCase(); } catch { return ""; } }
function registeredDomain(host) {
    const l = host.split(".").filter(Boolean);
    if (l.length >= 3 && l[l.length - 1].length === 2 && SECOND_LEVEL.has(l[l.length - 2])) return l.slice(-3).join(".");
    return l.length >= 2 ? l.slice(-2).join(".") : host;
}
function el(tag, className, text) {
    const n = document.createElement(tag);
    if (className) n.className = className;
    if (text !== undefined) n.textContent = text;
    return n;
}
let currentSettings = { threshold: 0.50, notifications: true, autoScan: true };   // loaded from Settings

const predictionCache = new Map();   // same URL / same domain -> ask the model only once

async function predictUrl(url) {
    if (predictionCache.has(url)) return predictionCache.get(url);
    const features = extractFeatureArray(url);                       // from features.js (30 features)
    const r = await chrome.runtime.sendMessage({ type: "PREDICT_URL", features });
    if (!r || r.success !== true) throw new Error(r?.error || "The model did not return a prediction.");
    predictionCache.set(url, r);
    return r;
}

// Random Forest checks the FULL URL and its WEBSITE, then
// decidePhishing() (features.js) gives the verdict. Same rule as background.js.
// phishingProbability = the probability that decided the verdict
// (>= 0.50 means phishing), so the rest of the popup code stays the same.
async function predictDecision(url) {
    const { full, domainProbability, coreProbability, decision: d } =
        await checkUrlWithModel(url, predictUrl, currentSettings.threshold);
    // when the website itself is clearly legitimate, show the website's score
    const shown = d.basis === "website" ? domainProbability
                : d.basis === "link" ? coreProbability
                : d.score;
    return {
        ...full,
        phishingProbability: shown,
        legitimateProbability: 1 - shown,
        isPhishing: d.isPhishing,
        basis: d.basis,
        fullProbability: full.phishingProbability,
        domainProbability
    };
}

// ---------- runs INSIDE the web page (must be self-contained) ----------
function scanPageInPage() {
    const q = s => [...document.querySelectorAll(s)];
    const abs = u => { try { return new URL(u, location.href).href; } catch { return ""; } };
    const hostOf = u => { try { return new URL(u, location.href).hostname.toLowerCase(); } catch { return ""; } };
    const sensRe = /(card|cvv|cvc|otp|pin\b|ssn|social.?security|expiry|account.?number)/i;

    const forms = q("form").map(f => ({
        actionAbs: abs(f.getAttribute("action") || location.href),
        hasPassword: !!f.querySelector('input[type="password"]')
    }));
    const anchors = q("a[href]");
    const realLinks = anchors.map(a => a.href).filter(h => /^https?:/i.test(h));
    const og = document.querySelector('meta[property="og:site_name"]');
    const titles = {};   // readable name of each link (e.g. the video title)
    anchors.forEach(a => {
        const h = a.href;
        if (/^https?:/i.test(h) && !titles[h])
            titles[h] = ((a.dataset.pgOrig !== undefined ? a.dataset.pgOrig : a.getAttribute("title")) || a.getAttribute("aria-label") || a.textContent || "").replace(/\s+/g, " ").trim().slice(0, 70);
    });
    return {
        pageHost: location.hostname.toLowerCase(),
        protocol: location.protocol,
        title: document.title || "",
        siteName: og ? og.content : "",
        forms,
        pwCount: q('input[type="password"]').length,
        sensitiveCount: q("input").filter(i => sensRe.test([i.name, i.id, i.placeholder, i.autocomplete].join(" "))).length,
        hiddenIframes: q("iframe").filter(i => {
            const r = i.getBoundingClientRect(), cs = getComputedStyle(i);
            return r.width <= 2 || r.height <= 2 || cs.display === "none" || cs.visibility === "hidden";
        }).length,
        totalAnchors: anchors.length,
        nullLinks: anchors.filter(a => {
            const h = (a.getAttribute("href") || "").trim().toLowerCase();
            return h === "" || h === "#" || h.startsWith("javascript:");
        }).length,
        resourceHosts: q("img[src],script[src],link[rel~=stylesheet][href]").slice(0, 400).map(e => hostOf(e.src || e.href)).filter(Boolean),
        metaRefresh: !!document.querySelector('meta[http-equiv="refresh" i]'),
        hrefs: [...new Set(realLinks)].slice(0, 300),
        titles
    };
}


// ---------- runs INSIDE the web page: marks every scanned link ----------
function markLinksInPage(results) {
    const map = new Map(results.map(r => [r[0], r]));
    document.querySelectorAll("a[href]").forEach(a => {
        const r = map.get(a.href);
        if (!r) return;
        if (a.dataset.pgOrig === undefined) a.dataset.pgOrig = a.title || "";
        const phishing = r[1], pctValue = r[2];
        a.dataset.pgScan = phishing ? "phishing" : "legit";
        if (phishing) { a.style.outline = "3px solid #d93025"; a.style.outlineOffset = "2px"; }
        a.title = (phishing ? `GRJD Shield: PHISHING (${pctValue}%)` : `GRJD Shield: Legitimate (${pctValue}% risk)`) +
                  (a.dataset.pgOrig ? "\n" + a.dataset.pgOrig : "");
    });
}

// ---------- page-content analysis (rule-based) ----------
function analyzeContent(d) {
    const reg = registeredDomain(d.pageHost), regLabel = reg.split(".")[0];
    const findings = []; let score = 0;
    const add = (pts, text) => { score += pts; findings.push({ pts, text }); };
    const hasLogin = d.pwCount > 0;

    const extLogin = d.forms.filter(f => f.hasPassword && registeredDomain(hostOf(f.actionAbs)) !== reg);
    if (extLogin.length) add(35, `The login form sends data to a different domain (${hostOf(extLogin[0].actionAbs)})`);
    if (hasLogin && d.protocol !== "https:") add(25, "The page has a password field but does not use HTTPS");

    const titleText = `${d.title} ${d.siteName}`.toLowerCase();
    const brand = BRANDS.find(b => titleText.includes(b) && regLabel !== b && !reg.includes(b));
    if (brand) {
        if (hasLogin || d.sensitiveCount) add(25, `Uses the name "${brand}" in the title but is not its real domain, and asks for login or sensitive information`);
        else add(5, `The title mentions "${brand}" (not the domain of this site)`);
    }
    if (d.sensitiveCount) add(10, `Has ${d.sensitiveCount} input field(s) for sensitive data (card/OTP/PIN/account)`);
    if (d.hiddenIframes) add(8, `Has ${d.hiddenIframes} hidden iframe(s)`);
    if (d.totalAnchors >= 5 && d.nullLinks / d.totalAnchors >= 0.5)
        add(12, `${d.nullLinks} of ${d.totalAnchors} links have no real destination (#/javascript:)`);
    if (hasLogin && d.resourceHosts.length >= 10) {
        const ext = d.resourceHosts.filter(h => registeredDomain(h) !== reg).length / d.resourceHosts.length;
        if (ext >= 0.7) add(6, `${Math.round(ext * 100)}% of images/scripts come from other domains (possibly a copied page)`);
    }
    if (d.metaRefresh) add(10, "Has an automatic redirect (meta refresh)");

    return { score: Math.min(score, 100), findings, hasLogin };
}

// ---------- final verdict (URL model + page content) ----------
function finalVerdict(urlPhishing, urlStrong, contentScore) {
    if (urlStrong) return "PHISHING";
    if (urlPhishing && contentScore >= 35) return "PHISHING";
    if (urlPhishing) return "SUSPICIOUS";
    if (contentScore >= 60) return "PHISHING";
    if (contentScore >= 35) return "SUSPICIOUS";
    return "LEGITIMATE";
}

// ---------- STEP 2 (Scan): scan the INSIDE of the website ----------
function buildContentBody(content, page, contentErr) {
    const card = el("div", "collapse-body");
    if (!content) { card.appendChild(el("p", "muted", contentErr)); return card; }
    const bar = el("div", "bar"); const fill = document.createElement("i");
    fill.style.width = content.score + "%"; bar.appendChild(fill);
    card.appendChild(el("div", "muted", `Content risk score: ${content.score}/100`));
    card.appendChild(bar);
    const stats = el("div", "stats");
    [`${page.forms.length} form(s)`, `${page.pwCount} password field(s)`, `${page.totalAnchors} link(s)`,
     `${page.hiddenIframes} hidden iframe(s)`, page.protocol === "https:" ? "HTTPS" : "No HTTPS"]
        .forEach(t => stats.appendChild(el("span", "chip", t)));
    card.appendChild(stats);
    const ul = document.createElement("ul");
    if (!content.findings.length) ul.appendChild(el("li", "ok", "No suspicious signals found in the page content."));
    content.findings.forEach(f => {
        const li = document.createElement("li");
        li.appendChild(el("span", "pts", `+${f.pts} `)); li.appendChild(document.createTextNode(f.text));
        ul.appendChild(li);
    });
    card.appendChild(ul);
    return card;
}

// ---------- WEBSITE CONTENT: every link inside the page ----------
async function scanLinks(page) {
    const items = page.hrefs.slice(0, MAX_LINKS_TO_SCAN).map(u => ({
        url: u,
        title: (page.titles && page.titles[u]) || ""
    }));
    const results = [];
    for (let i = 0; i < items.length; i += 8) {
        const chunk = items.slice(i, i + 8);
        const res = await Promise.allSettled(chunk.map(c => predictDecision(c.url)));   // Random Forest
        res.forEach((r, j) => {
            if (r.status !== "fulfilled") return;
            const p = r.value.phishingProbability;
            results.push({ ...chunk[j], p, phishing: r.value.isPhishing });
        });
    }
    return results.sort((x, y) => y.p - x.p);
}

function buildLinksBody(page, linkResults, linkErr) {
    const body = el("div", "collapse-body");
    if (!page) { body.appendChild(el("p", "muted", linkErr)); return body; }
    if (!linkResults.length) { body.appendChild(el("p", "muted", "No links were found on this page.")); return body; }

    const legit = linkResults.filter(r => !r.phishing);
    const flagged = linkResults.filter(r => r.phishing);

    const row = r => {
        const div = el("div", "link-row " + (r.phishing ? "phish" : "legit"));
        div.appendChild(el("span", "link-label", r.title || r.url));
        div.title = r.url;
        return div;
    };
    const group = (cls, title, list) => {
        const g = el("div", "link-group " + cls);
        g.appendChild(el("div", "link-group-title", `${title} (${list.length})`));
        const box = el("div", "link-list");
        list.forEach(r => box.appendChild(row(r)));
        g.appendChild(box);
        return g;
    };

    if (flagged.length) body.appendChild(group("phish", "Phishing", flagged));
    if (legit.length) body.appendChild(group("legit", "Legitimate", legit));
    if (page.hrefs.length > MAX_LINKS_TO_SCAN) {
        body.appendChild(el("p", "muted", `Only the first ${MAX_LINKS_TO_SCAN} links were scanned.`));
    }
    return body;
}

// ---------- collapsible section ----------
function collapsible(title, subtitle, body) {
    const d = el("details", "card collapse");
    const summary = document.createElement("summary");
    const text = el("div", "collapse-text");
    text.appendChild(el("span", "collapse-title", title));
    text.appendChild(el("span", "collapse-sub", subtitle));
    summary.appendChild(text);
    summary.appendChild(el("span", "collapse-arrow", ""));
    d.appendChild(summary);
    d.appendChild(body);
    return d;
}


// ---------- small helpers for the new design ----------
function pct(v) {
    return (v * 100).toFixed(2) + "%";
}

function formatDateTime(ms) {
    const d = new Date(ms);
    const date = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    const time = d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
    return `${date}, ${time}`;
}

function svgIcon(id, className) {
    const NS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(NS, "svg");
    if (className) svg.setAttribute("class", className);
    svg.setAttribute("aria-hidden", "true");
    const use = document.createElementNS(NS, "use");
    use.setAttribute("href", "#" + id);
    svg.appendChild(use);
    return svg;
}

const VERDICT_TEXT = {
    PHISHING:   ["Phishing Website",   "This website may steal your information."],
    SUSPICIOUS: ["Suspicious Website", "Some warning signs were found. Be careful."],
    LEGITIMATE: ["Legitimate Website", "No phishing signs detected."]
};

// small verdict card used on the Scan and Manual pages
function verdictBanner(verdict) {
    const cls = { PHISHING: "phish", SUSPICIOUS: "susp", LEGITIMATE: "legit" }[verdict];
    const box = el("div", "pg-banner " + cls);
    box.appendChild(svgIcon(verdict === "LEGITIMATE" ? "i-check" : "i-alert"));
    const text = el("div", "");
    text.appendChild(el("strong", "", VERDICT_TEXT[verdict][0]));
    text.appendChild(el("span", "", VERDICT_TEXT[verdict][1]));
    box.appendChild(text);
    return box;
}

function probabilityTiles(phishingProbability) {
    const wrap = el("div", "pg-tiles");
    [["legit", "i-check", "Legitimate", 1 - phishingProbability],
     ["phish", "i-alert", "Phishing", phishingProbability]].forEach(([cls, icon, label, v]) => {
        const tile = el("div", "pg-tile " + cls);
        tile.appendChild(svgIcon(icon));
        const t = el("div", "");
        t.appendChild(el("span", "", label));
        t.appendChild(el("strong", "", pct(v)));
        tile.appendChild(t);
        wrap.appendChild(tile);
    });
    return wrap;
}

function infoTile(label, value) {
    const tile = el("div", "pg-info");
    tile.appendChild(el("span", "", label));
    tile.appendChild(el("strong", "", value));
    return tile;
}

// ---------- HOME: URL check of the open tab ----------
let state = null;

function setHomeVerdict(ui, verdict, title, sub) {
    ui.verdictCard.className = "pg-card pg-verdict " + verdict;
    ui.verdictUse.setAttribute("href", verdict === "phish" || verdict === "susp" ? "#i-shield-bad" : "#i-shield-ok");
    ui.verdictTitle.textContent = title;
    ui.verdictSub.textContent = sub;
}

async function checkCurrentTab(tab, ui) {
    state = null;
    ui.scanButton.disabled = true;
    let parsed = null;
    try { parsed = new URL(tab.url || ""); } catch { /* ignore */ }

    if (!parsed || !["http:", "https:"].includes(parsed.protocol)) {
        ui.currentHost.textContent = tab.url ? "Browser page" : "No website";
        setHomeVerdict(ui, "na", "Cannot be scanned", "Browser and extension pages cannot be checked.");
        return;
    }

    ui.currentHost.textContent = parsed.hostname;
    setHomeVerdict(ui, "checking", "Checking website...", "The Random Forest is analyzing this URL.");

    let urlRes;
    try {
        urlRes = await predictDecision(tab.url);   // Random Forest: full URL + domain
    } catch (e) {
        setHomeVerdict(ui, "na", "Unable to check", e.message);
        return;
    }

    const verdict = urlRes.isPhishing ? "PHISHING" : "LEGITIMATE";
    setHomeVerdict(ui, urlRes.isPhishing ? "phish" : "legit", VERDICT_TEXT[verdict][0], VERDICT_TEXT[verdict][1]);
    ui.legitValue.textContent = pct(urlRes.legitimateProbability);
    ui.phishValue.textContent = pct(urlRes.phishingProbability);

    state = { tab, parsed, urlRes, scanning: false };
    ui.scanButton.disabled = false;
}

// ---------- SCAN: links inside the website + page content ----------
async function runScan(ui) {
    if (!state) {
        ui.scanResult.replaceChildren(el("p", "pg-muted", "There is no website to scan."));
        return;
    }
    if (state.scanning) return;
    state.scanning = true;

    const { tab, parsed, urlRes } = state;
    ui.scanAgain.hidden = true;
    ui.scanResult.replaceChildren(el("div", "pg-loading", "Scanning the website..."));

    let page = null, contentErr = "";
    try {
        const [out] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scanPageInPage });
        page = out && out.result;
    } catch (e) {
        contentErr = "The content of this page cannot be read (protected by the browser).";
    }
    const content = page ? analyzeContent(page) : null;

    // every link inside the website (videos, posts, buttons...) -> Random Forest
    let linkResults = [];
    if (page) {
        ui.scanResult.replaceChildren(el("div", "pg-loading",
            `Scanning ${Math.min(page.hrefs.length, MAX_LINKS_TO_SCAN)} links inside the website...`));
        linkResults = await scanLinks(page);
        try {   // red outline on phishing links in the real page
            await chrome.scripting.executeScript({
                target: { tabId: tab.id }, func: markLinksInPage,
                args: [linkResults.map(r => [r.url, r.phishing, Math.round(r.p * 100)])]
            });
        } catch (e) { /* page cannot be marked */ }
    }

    const verdict = content
        ? finalVerdict(urlRes.isPhishing, urlRes.isPhishing, content.score)
        : (urlRes.isPhishing ? "PHISHING" : "LEGITIMATE");
    const scannedAt = Date.now();

    const nPhish = linkResults.filter(r => r.phishing).length;
    const linksSection = collapsible("Website Content (Links)",
        page ? `${linkResults.length} links · ${linkResults.length - nPhish} legitimate · ${nPhish} phishing`
             : "Not available for this page",
        buildLinksBody(page, linkResults, contentErr));
    linksSection.open = true;

    const tiles = el("div", "pg-info-row");
    tiles.appendChild(infoTile("Website", parsed.hostname));
    tiles.appendChild(infoTile("Scan Time", formatDateTime(scannedAt)));

    ui.scanResult.replaceChildren(
        verdictBanner(verdict),
        tiles,
        linksSection,
        collapsible("Page Content Analysis",
            content ? `Content risk score: ${content.score}/100` : "Not available for this page",
            buildContentBody(content, page, contentErr))
    );

    ui.scanAgain.hidden = false;
    state.scanning = false;
    state.scanned = true;

    await addHistory({ host: parsed.hostname, url: tab.url, time: scannedAt, verdict });
}

// ---------- HISTORY (chrome.storage.local, 5 per page) ----------
async function getHistory() {
    try {
        const data = await chrome.storage.local.get(HISTORY_KEY);
        return Array.isArray(data[HISTORY_KEY]) ? data[HISTORY_KEY] : [];
    } catch {
        return [];
    }
}

async function addHistory(entry) {
    try {
        const list = await getHistory();
        list.unshift(entry);
        await chrome.storage.local.set({ [HISTORY_KEY]: list.slice(0, MAX_HISTORY) });
    } catch (e) {
        console.warn("History not saved:", e.message);
    }
}

const AVATAR_COLORS = ["#6b54c6", "#2f8f63", "#d95762", "#3b7dd8", "#c98a1b", "#8b4fb3"];

function avatarFor(host) {
    const name = host.replace(/^www\./, "");
    let hash = 0;
    for (const ch of name) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
    const a = el("span", "pg-avatar", (name[0] || "?").toUpperCase());
    a.style.background = AVATAR_COLORS[hash % AVATAR_COLORS.length];
    return a;
}

// true when the visible pixels of the logo are mostly white / very light
function isLightLogo(img) {
    try {
        const size = 32;
        const canvas = document.createElement("canvas");
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, size, size);
        const data = ctx.getImageData(0, 0, size, size).data;
        let total = 0, count = 0;
        for (let i = 0; i < data.length; i += 4) {
            if (data[i + 3] < 100) continue;   // skip transparent pixels
            total += 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
            count++;
        }
        return count > 0 && total / count > 215;
    } catch {
        return false;
    }
}

// website logo from Chrome's own favicon cache (no internet request).
// Needs the "favicon" permission in manifest.json. Falls back to the letter.
function faviconFor(h) {
    const box = el("span", "pg-avatar pg-favicon");
    const img = document.createElement("img");
    img.alt = "";
    img.width = 22;
    img.height = 22;
    try {
        const pageUrl = h.url || ("https://" + h.host + "/");
        const src = new URL(chrome.runtime.getURL("/_favicon/"));
        src.searchParams.set("pageUrl", pageUrl);
        src.searchParams.set("size", "32");
        img.src = src.href;
    } catch {
        return avatarFor(h.host || "?");
    }
    img.addEventListener("error", () => box.replaceWith(avatarFor(h.host || "?")));
    // white / very light logos (e.g. ChatGPT) are invisible on white -> dark box
    img.addEventListener("load", () => {
        if (isLightLogo(img)) box.classList.add("dark");
    });
    box.appendChild(img);
    return box;
}

let historyPage = 0;

async function renderHistory(ui) {
    const list = await getHistory();
    const pages = Math.max(1, Math.ceil(list.length / HISTORY_PAGE_SIZE));
    historyPage = Math.min(Math.max(historyPage, 0), pages - 1);
    const start = historyPage * HISTORY_PAGE_SIZE;
    const shown = list.slice(start, start + HISTORY_PAGE_SIZE);

    ui.historyList.replaceChildren();
    if (!list.length) {
        ui.historyList.appendChild(el("p", "pg-muted pg-empty", "No scanned websites yet."));
    }
    shown.forEach(h => {
        const row = el("div", "pg-history-row");
        row.title = h.url || h.host;
        const bad = h.verdict === "PHISHING" || h.verdict === "SUSPICIOUS";
        // legitimate -> real website logo (favicon) | phishing -> colored letter
        row.appendChild(bad ? avatarFor(h.host || "?") : faviconFor(h));
        const text = el("div", "pg-history-text");
        text.appendChild(el("strong", "", h.host));
        text.appendChild(el("span", "", formatDateTime(h.time)));
        row.appendChild(text);

        const badge = el("span", "pg-badge " + (bad ? "phish" : "safe"));
        badge.appendChild(svgIcon(bad ? "i-alert" : "i-check"));
        badge.appendChild(document.createTextNode(h.verdict === "SUSPICIOUS" ? "Suspicious" : bad ? "Phishing" : "Safe"));
        row.appendChild(badge);
        ui.historyList.appendChild(row);
    });

    ui.historyInfo.textContent = list.length
        ? `Showing ${start + 1}-${start + shown.length} of ${list.length} scans`
        : "Showing 0 of 0 scans";
    ui.historyPrev.disabled = historyPage === 0;
    ui.historyNext.disabled = historyPage >= pages - 1;
}

// ---------- SETTINGS ----------
function showSettings(ui, s) {
    ui.notificationsInput.checked = !!s.notifications;
    ui.autoScanInput.checked = !!s.autoScan;
}

async function storeSettings(ui) {
    currentSettings = {
        threshold: DEFAULT_SETTINGS.threshold,   // fixed at 0.50 (not changeable by the user)
        notifications: ui.notificationsInput.checked,
        autoScan: ui.autoScanInput.checked
    };
    showSettings(ui, currentSettings);
    try { await saveSettings(currentSettings); } catch (e) { console.warn("Settings not saved:", e.message); }
}

// ---------- POPUP WIRING ----------
document.addEventListener("DOMContentLoaded", async () => {
    const $ = id => document.getElementById(id);
    const ui = {
        pages: { home: $("pageHome"), scan: $("pageScan"), history: $("pageHistory"), manual: $("pageManual"), settings: $("pageSettings") },
        currentHost: $("currentHost"), verdictCard: $("verdictCard"), verdictUse: document.querySelector("#verdictSvg use"),
        verdictTitle: $("verdictTitle"), verdictSub: $("verdictSub"),
        legitValue: $("legitValue"), phishValue: $("phishValue"),
        scanButton: $("scanButton"), openManual: $("openManual"), openSettings: $("openSettings"),
        backFromScan: $("backFromScan"), scanResult: $("scanResult"), scanAgain: $("scanAgainButton"),
        historyList: $("historyList"), historyInfo: $("historyInfo"),
        historyPrev: $("historyPrev"), historyNext: $("historyNext"), clearHistory: $("clearHistoryButton"),
        urlInput: $("urlInput"), checkButton: $("checkButton"), result: $("result"),
        notificationsInput: $("notificationsInput"), autoScanInput: $("autoScanInput"),
        resetSettings: $("resetSettings"), aboutText: $("aboutText"),
        navResult: $("navResult"), navRight: $("navRight"),
        navRightIcon: $("navRightIcon"), navRightLabel: $("navRightLabel")
    };
    const missing = Object.entries(ui).filter(([k, v]) => k !== "pages" && !v).map(([k]) => k);
    if (missing.length || Object.values(ui.pages).some(p => !p)) {
        console.error("Popup HTML is missing an element:", missing);
        return;
    }

    // ----- navigation -----
    // bottom bar: left = Result, right = History (or Manual Check / Settings when open)
    const RIGHT_NAV = {
        history:  ["#i-clock", "History"],
        manual:   ["#i-hand", "Manual Check"],
        settings: ["#i-gear", "Settings"]
    };
    let currentPage = "home";

    function showPage(name) {
        currentPage = name;
        Object.entries(ui.pages).forEach(([key, page]) => { page.hidden = key !== name; });
        const right = RIGHT_NAV[name] || RIGHT_NAV.history;
        ui.navRightIcon.setAttribute("href", right[0]);
        ui.navRightLabel.textContent = right[1];
        // Result is underlined only on the Scan Result page (not on Home)
        ui.navRight.classList.toggle("active", name in RIGHT_NAV);
        ui.navResult.classList.toggle("active", name === "scan");
        window.scrollTo(0, 0);
        if (name === "history") renderHistory(ui);
    }

    // Result: last scan result, or Home if nothing was scanned yet
    ui.navResult.addEventListener("click", () => showPage(state && state.scanned ? "scan" : "home"));
    // logo / name at the top -> Home
    document.querySelectorAll(".pg-logo, .pg-brand").forEach(n =>
        n.addEventListener("click", () => showPage("home")));
    ui.navRight.addEventListener("click", () => {
        if (currentPage === "manual" || currentPage === "settings") return;
        historyPage = 0;
        showPage("history");
    });
    ui.openManual.addEventListener("click", () => { showPage("manual"); ui.urlInput.focus(); });
    ui.openSettings.addEventListener("click", () => showPage("settings"));
    // back buttons -> Home
    ["backFromScan", "backFromHistory", "backFromManual", "backFromSettings"].forEach(id =>
        $(id).addEventListener("click", () => showPage("home")));

    ui.scanButton.addEventListener("click", () => { showPage("scan"); runScan(ui); });
    ui.scanAgain.addEventListener("click", () => runScan(ui));

    // ----- history -----
    ui.historyPrev.addEventListener("click", () => { historyPage--; renderHistory(ui); });
    ui.historyNext.addEventListener("click", () => { historyPage++; renderHistory(ui); });
    ui.clearHistory.addEventListener("click", async () => {
        try { await chrome.storage.local.remove(HISTORY_KEY); } catch { /* ignore */ }
        historyPage = 0;
        renderHistory(ui);
    });

    // ----- settings -----
    currentSettings = await loadSettings();
    showSettings(ui, currentSettings);
    try {
        const m = chrome.runtime.getManifest();
        ui.aboutText.replaceChildren(document.createTextNode(`GRJD Shield v${m.version}`),
            document.createElement("br"), document.createTextNode("Built by four, protecting all."));
    } catch { /* keep default text */ }

    ui.notificationsInput.addEventListener("change", () => storeSettings(ui));
    ui.autoScanInput.addEventListener("change", () => storeSettings(ui));
    ui.resetSettings.addEventListener("click", async () => {
        currentSettings = { ...DEFAULT_SETTINGS };
        showSettings(ui, currentSettings);
        try { await saveSettings(currentSettings); } catch { /* ignore */ }
    });

    showPage("home");

    // ----- automatic URL check of the open website -----
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) await checkCurrentTab(tab, ui);
    } catch (e) {
        console.error("URL check failed:", e);
        setHomeVerdict(ui, "na", "Unable to check", "Unable to check this page.");
    }

    // ----- MANUAL CHECK -----
    const { checkButton, urlInput, result } = ui;
    urlInput.addEventListener("keydown", e => { if (e.key === "Enter") checkButton.click(); });
    checkButton.addEventListener("click", async () => {
        const raw = urlInput.value.trim();
        result.replaceChildren();
        let parsedUrl;
        try { parsedUrl = new URL(raw); } catch {
            result.appendChild(el("p", "pg-error", "Invalid URL. Include https:// or http://."));
            return;
        }
        if (!["http:", "https:"].includes(parsedUrl.protocol)) {
            result.appendChild(el("p", "pg-error", "Only HTTP and HTTPS URLs can be checked."));
            return;
        }

        checkButton.disabled = true;
        try {
            const r = await predictDecision(parsedUrl.href);   // Random Forest: full URL + domain
            const verdict = r.isPhishing ? "PHISHING" : "LEGITIMATE";
            result.replaceChildren(verdictBanner(verdict), probabilityTiles(r.phishingProbability));

            await addHistory({ host: parsedUrl.hostname, url: parsedUrl.href, time: Date.now(), verdict });

            if (r.isPhishing) {
                const w = new URL(chrome.runtime.getURL("warning.html"));
                w.searchParams.set("url", parsedUrl.href);
                w.searchParams.set("probability", String(r.phishingProbability));
                await chrome.tabs.create({ url: w.href });
            }
        } catch (error) {
            result.replaceChildren(el("p", "pg-error", error.message || "An unexpected error occurred."));
        } finally {
            checkButton.disabled = false;
        }
    });
});
